-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2021 at 04:15 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `moneyvalue`
--

CREATE TABLE `moneyvalue` (
  `id` int(11) NOT NULL,
  `treasure_id` int(11) NOT NULL,
  `amt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `moneyvalue`
--

INSERT INTO `moneyvalue` (`id`, `treasure_id`, `amt`) VALUES
(1, 1, 15),
(2, 1, 20),
(14, 2, 10),
(15, 2, 25),
(16, 3, 15),
(17, 3, 20),
(18, 4, 15),
(19, 4, 25),
(20, 5, 10),
(21, 6, 15),
(22, 7, 15),
(23, 8, 10),
(24, 8, 30),
(25, 9, 15),
(26, 9, 30),
(27, 10, 15),
(28, 10, 30),
(29, 11, 10),
(30, 12, 15),
(31, 13, 15),
(32, 14, 10),
(33, 15, 15),
(34, 16, 15),
(35, 17, 18),
(36, 18, 15);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `moneyvalue`
--
ALTER TABLE `moneyvalue`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `moneyvalue`
--
ALTER TABLE `moneyvalue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
