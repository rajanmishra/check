function getNewString(str, placeToMove) 
{ 
    if(!str) return "No string found";
	placeToMove = (placeToMove && Number(placeToMove)) || 0;
    let newStr = ""; 
    for(let i = 0; i < str.length; ++i) 
    { 
        let val = str.charCodeAt(i);
	    //check if maximum limit reachead to z to handle in cyclic manner 		
        if(val + placeToMove > 122) 
        { 
            let tempInc = placeToMove -  (122 - val); 
            tempInc = tempInc % 26; 
            newStr = newStr + String.fromCharCode(96 + tempInc); 
        } 
        else{
            newStr = newStr + String.fromCharCode(val + placeToMove); 
		}
  
    } 
	return newStr;
} 

getNewString("abc", 2);
getNewString("abc", 28);


//Answer2
//you have to make conversion from ASCII to string and  string to ASCII , instead of refering to ASCII value we can make our own referce array with value against each char as its index and apply the same logic.