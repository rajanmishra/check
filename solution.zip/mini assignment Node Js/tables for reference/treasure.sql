-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 21, 2021 at 03:30 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `demo`
--

-- --------------------------------------------------------

--
-- Table structure for table `treasure`
--

CREATE TABLE `treasure` (
  `id` int(11) NOT NULL,
  `latitude` decimal(10,8) NOT NULL,
  `longitude` decimal(11,8) NOT NULL,
  `name` varchar(512) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `treasure`
--

INSERT INTO `treasure` (`id`, `latitude`, `longitude`, `name`) VALUES
(1, '1.33125924', '103.89804864', 'T1'),
(2, '1.32255754', '103.89430855', 'T2'),
(3, '1.31663560', '103.88912254', 'T3'),
(4, '1.31286055', '103.85455645', 'T4'),
(5, '1.34439896', '103.87659381', 'T5'),
(6, '1.33616189', '103.87708662', 'T6'),
(7, '1.32552844', '103.86910143', 'T7'),
(8, '1.32303589', '103.87748154', 'T8'),
(9, '1.33465304', '103.87044897', 'T9'),
(10, '1.32606138', '103.87930069', 'T10'),
(11, '1.25886946', '103.89887904', 'T11'),
(12, '1.26973345', '103.88104480', 'T12'),
(13, '1.32914713', '103.83347810', 'T13'),
(14, '1.32960595', '103.88079366', 'T14'),
(15, '1.33700251', '103.84922492', 'T15'),
(16, '1.27845714', '103.85717615', 'T16'),
(17, '1.36019784', '103.85635821', 'T17'),
(18, '1.31551921', '103.86328390', 'T18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `treasure`
--
ALTER TABLE `treasure`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `treasure`
--
ALTER TABLE `treasure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
